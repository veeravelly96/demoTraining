#!/bin/bash

VAR_NAME="Shell Scripting is Fun!"
echo "$VAR_NAME"
#SERVER="Hostname"
#echo "This script is running on ${SERVER}"
