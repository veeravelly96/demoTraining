#!/bin/bash

ACCESS="/etc/shadow"
if  [-e $ACCESS]
then
 echo "Shadow passwords are enabled"
elif [-w $ACCESS]
then
 echo "You have permissions to edit /etc/shadow."
else
echo "You do NOT have permissions to edit /etc/shadow"
fi