#!/bin/bash
 
for ACCESS in $@
do 
if [ -d $ACCESS ]
then
        echo "$ACCESS is a directory"
elif [ -f $ACCESS ]
then
        echo "$ACCESS is a simple file"
elif [ -e $ACCESS ]
then
        echo "$ACCESS is not a simple file"
else
        echo "$ACCESS does NOT exist!!"
fi
 
echo "$(ls -l $ACCESS)"
done